﻿namespace AcademyEcosystem.Plants
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Grass : Plant
    {
        public Grass(Point location) : base(location, 2)
        {

        }

        public override void Update(int time)
        {
            // Don't know how to implement each time unit.
            if (time > 0 && this.IsAlive)
            {
                this.Size += time;
            }
        }
    }
}

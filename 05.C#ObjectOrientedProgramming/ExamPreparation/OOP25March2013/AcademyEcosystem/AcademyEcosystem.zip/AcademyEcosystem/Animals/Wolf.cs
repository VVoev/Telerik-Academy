﻿namespace AcademyEcosystem.Animals
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Wolf : Animal, ICarnivore
    {

        public Wolf(string name, Point location)
            : base(name, location, 4)
        {

        }

        public int TryEatAnimal(Animal animal)
        {
            int quantityOfEatenMeat = 0;
            if (animal != null)
            {
                if (this.Size >= animal.Size || 
                    animal.State == AnimalState.Sleeping ||
                    animal is Zombie)
                {
                    quantityOfEatenMeat = animal.GetMeatFromKillQuantity();
                }
            }
            return quantityOfEatenMeat;
        }
    }
}
